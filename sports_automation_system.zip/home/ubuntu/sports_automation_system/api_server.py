#!/usr/bin/env python3
"""
Flask API Server for Sports Content Management
خادم واجهة برمجة التطبيقات لإدارة المحتوى الرياضي
"""

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import sqlite3
import json
from datetime import datetime, timedelta
import logging
import os
import threading
import time
from rss_collector import RSSCollector
from api_collector import APIFootballCollector
from content_generator import ContentGenerator

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)  # السماح بطلبات CORS من React

# إعدادات التطبيق
app.config['DATABASE'] = 'sports_content.db'
app.config['CONTENT_DIR'] = 'generated_content'

# متغيرات النظام
system_status = {'running': True, 'last_update': datetime.now()}
automation_thread = None

class DatabaseManager:
    """مدير قاعدة البيانات"""
    
    def __init__(self, db_path):
        self.db_path = db_path
    
    def get_connection(self):
        """الحصول على اتصال بقاعدة البيانات"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # للحصول على النتائج كقاموس
        return conn
    
    def execute_query(self, query, params=None):
        """تنفيذ استعلام وإرجاع النتائج"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            
            results = cursor.fetchall()
            conn.close()
            
            # تحويل النتائج إلى قائمة من القواميس
            return [dict(row) for row in results]
            
        except Exception as e:
            logger.error(f"خطأ في تنفيذ الاستعلام: {e}")
            return []

# إنشاء مدير قاعدة البيانات
db_manager = DatabaseManager(app.config['DATABASE'])

def automation_worker():
    """عامل الأتمتة الذي يعمل في الخلفية"""
    rss_collector = RSSCollector()
    api_collector = APIFootballCollector()
    content_generator = ContentGenerator()
    
    while system_status['running']:
        try:
            logger.info("بدء دورة التحديث التلقائي")
            
            # جمع البيانات من RSS
            rss_results = rss_collector.collect_all_sources()
            
            # جمع البيانات من API (إذا كان متوفراً)
            api_results = api_collector.collect_daily_data()
            
            # توليد المحتوى
            content_results = content_generator.generate_all_content()
            
            # تحديث وقت آخر تحديث
            system_status['last_update'] = datetime.now()
            
            logger.info("انتهت دورة التحديث التلقائي")
            
            # انتظار 30 دقيقة قبل الدورة التالية
            time.sleep(1800)  # 30 دقيقة
            
        except Exception as e:
            logger.error(f"خطأ في دورة الأتمتة: {e}")
            time.sleep(300)  # انتظار 5 دقائق في حالة الخطأ

@app.route('/api/status')
def get_system_status():
    """الحصول على حالة النظام"""
    return jsonify({
        'running': system_status['running'],
        'last_update': system_status['last_update'].isoformat(),
        'uptime': str(datetime.now() - system_status.get('start_time', datetime.now()))
    })

@app.route('/api/status/toggle', methods=['POST'])
def toggle_system_status():
    """تبديل حالة النظام (تشغيل/إيقاف)"""
    global automation_thread
    
    system_status['running'] = not system_status['running']
    
    if system_status['running'] and (automation_thread is None or not automation_thread.is_alive()):
        # بدء thread الأتمتة
        automation_thread = threading.Thread(target=automation_worker, daemon=True)
        automation_thread.start()
        logger.info("تم تشغيل النظام")
    else:
        logger.info("تم إيقاف النظام")
    
    return jsonify({
        'status': 'success',
        'running': system_status['running']
    })

@app.route('/api/stats')
def get_statistics():
    """الحصول على إحصائيات النظام"""
    try:
        # إحصائيات المقالات
        total_articles = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM articles"
        )[0]['count']
        
        today_articles = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM articles WHERE DATE(created_at) = DATE('now')"
        )[0]['count']
        
        # إحصائيات المباريات
        total_matches = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM matches"
        )[0]['count']
        
        today_matches = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM matches WHERE DATE(match_date) = DATE('now')"
        )[0]['count']
        
        # إحصائيات المصادر
        active_sources = 6  # عدد المصادر النشطة (يمكن حسابها ديناميكياً)
        total_sources = 8   # إجمالي المصادر
        
        return jsonify({
            'total_articles': total_articles,
            'today_articles': today_articles,
            'total_matches': total_matches,
            'today_matches': today_matches,
            'active_sources': active_sources,
            'total_sources': total_sources,
            'success_rate': 94  # يمكن حسابها بناءً على نجاح العمليات
        })
        
    except Exception as e:
        logger.error(f"خطأ في جلب الإحصائيات: {e}")
        return jsonify({'error': 'فشل في جلب الإحصائيات'}), 500

@app.route('/api/articles')
def get_articles():
    """الحصول على قائمة المقالات"""
    try:
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 20, type=int)
        offset = (page - 1) * limit
        
        articles = db_manager.execute_query(
            """
            SELECT id, title, summary, source_name, source_url, 
                   publication_date, category, language, created_at
            FROM articles 
            ORDER BY publication_date DESC, created_at DESC 
            LIMIT ? OFFSET ?
            """,
            (limit, offset)
        )
        
        # إجمالي عدد المقالات
        total = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM articles"
        )[0]['count']
        
        return jsonify({
            'articles': articles,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        })
        
    except Exception as e:
        logger.error(f"خطأ في جلب المقالات: {e}")
        return jsonify({'error': 'فشل في جلب المقالات'}), 500

@app.route('/api/matches')
def get_matches():
    """الحصول على قائمة المباريات"""
    try:
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 20, type=int)
        offset = (page - 1) * limit
        
        matches = db_manager.execute_query(
            """
            SELECT fixture_id, league_name, season, match_date, status,
                   home_team, away_team, home_score, away_score, venue
            FROM matches 
            ORDER BY match_date DESC 
            LIMIT ? OFFSET ?
            """,
            (limit, offset)
        )
        
        # إجمالي عدد المباريات
        total = db_manager.execute_query(
            "SELECT COUNT(*) as count FROM matches"
        )[0]['count']
        
        return jsonify({
            'matches': matches,
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        })
        
    except Exception as e:
        logger.error(f"خطأ في جلب المباريات: {e}")
        return jsonify({'error': 'فشل في جلب المباريات'}), 500

@app.route('/api/recent-articles')
def get_recent_articles():
    """الحصول على أحدث المقالات للوحة الرئيسية"""
    try:
        articles = db_manager.execute_query(
            """
            SELECT title, source_name, created_at, processed
            FROM articles 
            ORDER BY created_at DESC 
            LIMIT 5
            """
        )
        
        # تحويل التواريخ وإضافة معلومات إضافية
        for article in articles:
            created_at = datetime.fromisoformat(article['created_at'])
            now = datetime.now()
            diff = now - created_at
            
            if diff.seconds < 3600:  # أقل من ساعة
                article['time_ago'] = f"منذ {diff.seconds // 60} دقيقة"
            elif diff.seconds < 86400:  # أقل من يوم
                article['time_ago'] = f"منذ {diff.seconds // 3600} ساعة"
            else:
                article['time_ago'] = f"منذ {diff.days} يوم"
            
            article['status'] = 'published' if article['processed'] else 'pending'
        
        return jsonify(articles)
        
    except Exception as e:
        logger.error(f"خطأ في جلب المقالات الحديثة: {e}")
        return jsonify([])

@app.route('/api/upcoming-matches')
def get_upcoming_matches():
    """الحصول على المباريات القادمة"""
    try:
        matches = db_manager.execute_query(
            """
            SELECT home_team, away_team, league_name, match_date
            FROM matches 
            WHERE match_date > datetime('now') 
            ORDER BY match_date ASC 
            LIMIT 5
            """
        )
        
        # تحويل التواريخ وإضافة معلومات إضافية
        for match in matches:
            match_date = datetime.fromisoformat(match['match_date'])
            now = datetime.now()
            
            if match_date.date() == now.date():
                match['date'] = 'اليوم'
            elif match_date.date() == (now + timedelta(days=1)).date():
                match['date'] = 'غداً'
            else:
                match['date'] = match_date.strftime('%Y-%m-%d')
            
            match['time'] = match_date.strftime('%H:%M')
        
        return jsonify(matches)
        
    except Exception as e:
        logger.error(f"خطأ في جلب المباريات القادمة: {e}")
        return jsonify([])

@app.route('/api/manual-update', methods=['POST'])
def manual_update():
    """تحديث يدوي للبيانات"""
    try:
        # تشغيل عملية التحديث في thread منفصل
        def update_worker():
            rss_collector = RSSCollector()
            api_collector = APIFootballCollector()
            content_generator = ContentGenerator()
            
            # جمع البيانات
            rss_results = rss_collector.collect_all_sources()
            api_results = api_collector.collect_daily_data()
            content_results = content_generator.generate_all_content()
            
            # تحديث وقت آخر تحديث
            system_status['last_update'] = datetime.now()
        
        update_thread = threading.Thread(target=update_worker, daemon=True)
        update_thread.start()
        
        return jsonify({
            'status': 'success',
            'message': 'تم بدء التحديث اليدوي'
        })
        
    except Exception as e:
        logger.error(f"خطأ في التحديث اليدوي: {e}")
        return jsonify({'error': 'فشل في التحديث اليدوي'}), 500

@app.route('/api/content/<path:filename>')
def serve_content(filename):
    """تقديم ملفات المحتوى المولد"""
    try:
        return send_from_directory(app.config['CONTENT_DIR'], filename)
    except Exception as e:
        logger.error(f"خطأ في تقديم الملف: {e}")
        return jsonify({'error': 'الملف غير موجود'}), 404

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'المسار غير موجود'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'خطأ داخلي في الخادم'}), 500

def initialize_system():
    """تهيئة النظام عند البدء"""
    global automation_thread
    
    # تسجيل وقت بدء النظام
    system_status['start_time'] = datetime.now()
    
    # إنشاء قواعد البيانات والجداول
    rss_collector = RSSCollector()
    api_collector = APIFootballCollector()
    content_generator = ContentGenerator()
    
    # بدء thread الأتمتة إذا كان النظام يعمل
    if system_status['running']:
        automation_thread = threading.Thread(target=automation_worker, daemon=True)
        automation_thread.start()
        logger.info("تم بدء نظام الأتمتة")

if __name__ == '__main__':
    # تهيئة النظام
    initialize_system()
    
    # تشغيل الخادم
    logger.info("بدء خادم واجهة برمجة التطبيقات")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
