---
title: "الملخص الرياضي اليومي - 2025-10-09"
date: 2025-10-09
category: "ملخص يومي"
---

# الملخص الرياضي اليومي
## 9 أكتوبر 2025

## أبرز الأخبار


### 1. QMMF to host MENA Karting Championship Nations Cup for third consecutive year

&amp;lt;p&amp;gt;Doha: The Qatar Motor and Motorcycle Federation (QMMF) is once again set to bring the region&amp;amp;rsquo;s karting scene into the spotlight as it will host the MENA Karting Champion...

**المصدر:** The Peninsula Qatar Sports  
[اقرأ المزيد](https://thepeninsulaqatar.com/article/09/10/2025/qmmf-to-host-mena-karting-championship-nations-cup-for-third-consecutive-year)

---

### 2. Qatar held by Oman in goalless FIFA World Cup play-off opener

&amp;lt;p&amp;gt;Doha, Qatar: Qatar were held to a goalless draw by Oman in a cagey opening Group A clash of the 2026 FIFA World Cup Qualifiers play-offs stage at the Jassim Bin Hamad Stadium on Wedne...

**المصدر:** The Peninsula Qatar Sports  
[اقرأ المزيد](https://thepeninsulaqatar.com/article/08/10/2025/qatar-held-by-oman-in-goalless-start-to-world-cup-play-off-opener)

---

### 3. Oman vs Qatar FIFA World Cup 2026 Qualifiers

&amp;lt;p&amp;gt;Doha, Qatar: The Al Annabi national team kick off their campaign in a decisive World Cup qualification stage with a clash against Oman today, scheduled for 6pm Doha time.&amp;lt;/p&am...

**المصدر:** The Peninsula Qatar Sports  
[اقرأ المزيد](https://thepeninsulaqatar.com/article/08/10/2025/live-match-oman-vs-qatar-fifa-world-cup-2026-qualifiers)

---

### 4. QBF conducts league draw, launches first-ever Super Cup

&amp;lt;p&amp;gt;Doha, Qatar: The Qatar Basketball Federation (QBF) held the draw ceremony for 2025-2026 Men&amp;amp;rsquo;s General League yesterday evening at the Al Wasil Hall at the Qatar Olympic ...

**المصدر:** The Peninsula Qatar Sports  
[اقرأ المزيد](https://thepeninsulaqatar.com/article/08/10/2025/qbf-conducts-league-draw-launches-first-ever-super-cup)

---

### 5. Oman target strong start as Queiroz relishes Qatar test

&amp;lt;p&amp;gt;Doha, Qatar: Oman head coach Carlos Queiroz has stressed the challenge his side faces against hosts Qatar in their opening match of the fourth round of the AFC Asian Qualifiers for th...

**المصدر:** The Peninsula Qatar Sports  
[اقرأ المزيد](https://thepeninsulaqatar.com/article/08/10/2025/oman-target-strong-start-as-queiroz-relishes-qatar-test)

---


## نتائج المباريات


لا توجد مباريات اليوم.


## إحصائيات اليوم

- **عدد الأخبار الجديدة:** 40
- **عدد المباريات:** 0
- **آخر تحديث:** 05:36

---

*تم إنشاء هذا الملخص تلقائياً بواسطة نظام أتمتة المحتوى الرياضي*