#!/usr/bin/env python3
"""
Local Scheduler for Sports Content Automation
جدولة محلية لأتمتة المحتوى الرياضي
"""

import schedule
import time
import logging
import threading
from datetime import datetime
import subprocess
import os
import signal
import sys
from rss_collector import RSSCollector
from api_collector import APIFootballCollector
from content_generator import ContentGenerator

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scheduler.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SportsScheduler:
    """جدولة مهام أتمتة المحتوى الرياضي"""
    
    def __init__(self):
        self.running = True
        self.rss_collector = RSSCollector()
        self.api_collector = APIFootballCollector()
        self.content_generator = ContentGenerator()
        
        # إعداد معالج الإشارات للإغلاق الآمن
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """معالج إشارات الإغلاق"""
        logger.info(f"تم استلام إشارة {signum}، جاري الإغلاق الآمن...")
        self.running = False
        sys.exit(0)
    
    def collect_rss_data(self):
        """مهمة جمع البيانات من RSS"""
        try:
            logger.info("بدء مهمة جمع البيانات من RSS")
            results = self.rss_collector.collect_all_sources()
            
            total_new = sum(results.values())
            logger.info(f"انتهت مهمة RSS - تم جمع {total_new} مقال جديد")
            
            return results
            
        except Exception as e:
            logger.error(f"خطأ في مهمة جمع RSS: {e}")
            return {}
    
    def collect_api_data(self):
        """مهمة جمع البيانات من API"""
        try:
            logger.info("بدء مهمة جمع البيانات من API")
            results = self.api_collector.collect_daily_data()
            
            logger.info(f"انتهت مهمة API - المباريات: {results.get('fixtures', 0)}, الترتيب: {results.get('standings', 0)}")
            
            return results
            
        except Exception as e:
            logger.error(f"خطأ في مهمة جمع API: {e}")
            return {}
    
    def generate_content(self):
        """مهمة توليد المحتوى"""
        try:
            logger.info("بدء مهمة توليد المحتوى")
            results = self.content_generator.generate_all_content()
            
            total_generated = sum(results.values())
            logger.info(f"انتهت مهمة التوليد - تم إنشاء {total_generated} ملف")
            
            return results
            
        except Exception as e:
            logger.error(f"خطأ في مهمة توليد المحتوى: {e}")
            return {}
    
    def full_update_cycle(self):
        """دورة تحديث كاملة"""
        logger.info("=== بدء دورة التحديث الكاملة ===")
        start_time = datetime.now()
        
        try:
            # جمع البيانات من RSS
            rss_results = self.collect_rss_data()
            
            # جمع البيانات من API
            api_results = self.collect_api_data()
            
            # توليد المحتوى
            content_results = self.generate_content()
            
            # حفظ إحصائيات الدورة
            end_time = datetime.now()
            duration = end_time - start_time
            
            stats = {
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat(),
                'duration_seconds': duration.total_seconds(),
                'rss_articles': sum(rss_results.values()) if rss_results else 0,
                'api_fixtures': api_results.get('fixtures', 0) if api_results else 0,
                'api_standings': api_results.get('standings', 0) if api_results else 0,
                'generated_files': sum(content_results.values()) if content_results else 0
            }
            
            logger.info(f"=== انتهت دورة التحديث في {duration.total_seconds():.2f} ثانية ===")
            logger.info(f"الإحصائيات: {stats}")
            
            # حفظ الإحصائيات في ملف
            self.save_cycle_stats(stats)
            
        except Exception as e:
            logger.error(f"خطأ في دورة التحديث الكاملة: {e}")
    
    def quick_rss_update(self):
        """تحديث سريع لـ RSS فقط"""
        logger.info("=== بدء التحديث السريع لـ RSS ===")
        
        try:
            rss_results = self.collect_rss_data()
            content_results = self.generate_content()
            
            logger.info("=== انتهى التحديث السريع ===")
            
        except Exception as e:
            logger.error(f"خطأ في التحديث السريع: {e}")
    
    def daily_maintenance(self):
        """مهام الصيانة اليومية"""
        logger.info("=== بدء مهام الصيانة اليومية ===")
        
        try:
            # تنظيف قاعدة البيانات
            self.cleanup_database()
            
            # تنظيف الملفات القديمة
            self.cleanup_old_files()
            
            # إنشاء نسخة احتياطية
            self.create_backup()
            
            logger.info("=== انتهت مهام الصيانة اليومية ===")
            
        except Exception as e:
            logger.error(f"خطأ في مهام الصيانة: {e}")
    
    def cleanup_database(self):
        """تنظيف قاعدة البيانات"""
        try:
            import sqlite3
            
            conn = sqlite3.connect('sports_content.db')
            cursor = conn.cursor()
            
            # حذف المقالات الأقدم من 90 يوم
            cursor.execute("""
                DELETE FROM articles 
                WHERE created_at < datetime('now', '-90 days')
            """)
            
            deleted_articles = cursor.rowcount
            
            # حذف المباريات الأقدم من 180 يوم
            cursor.execute("""
                DELETE FROM matches 
                WHERE created_at < datetime('now', '-180 days')
            """)
            
            deleted_matches = cursor.rowcount
            
            # تحسين قاعدة البيانات
            cursor.execute("VACUUM")
            
            conn.commit()
            conn.close()
            
            logger.info(f"تنظيف قاعدة البيانات: حذف {deleted_articles} مقال و {deleted_matches} مباراة")
            
        except Exception as e:
            logger.error(f"خطأ في تنظيف قاعدة البيانات: {e}")
    
    def cleanup_old_files(self):
        """تنظيف الملفات القديمة"""
        try:
            import glob
            from pathlib import Path
            
            # حذف ملفات المحتوى الأقدم من 30 يوم
            content_dirs = ['generated_content/articles', 'generated_content/matches', 'generated_content/summaries']
            
            for content_dir in content_dirs:
                if os.path.exists(content_dir):
                    # استخدام find command لحذف الملفات القديمة
                    subprocess.run([
                        'find', content_dir, '-name', '*.md', 
                        '-mtime', '+30', '-delete'
                    ], check=False)
            
            # تنظيف ملفات السجلات القديمة
            log_files = glob.glob('*.log')
            for log_file in log_files:
                file_path = Path(log_file)
                if file_path.stat().st_mtime < (datetime.now().timestamp() - 7 * 24 * 3600):  # أقدم من 7 أيام
                    file_path.unlink()
            
            logger.info("تم تنظيف الملفات القديمة")
            
        except Exception as e:
            logger.error(f"خطأ في تنظيف الملفات: {e}")
    
    def create_backup(self):
        """إنشاء نسخة احتياطية"""
        try:
            import shutil
            from datetime import datetime
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_dir = f"backups/backup_{timestamp}"
            
            os.makedirs(backup_dir, exist_ok=True)
            
            # نسخ قاعدة البيانات
            if os.path.exists('sports_content.db'):
                shutil.copy2('sports_content.db', f"{backup_dir}/sports_content.db")
            
            # نسخ المحتوى المولد (آخر 7 أيام فقط)
            if os.path.exists('generated_content'):
                shutil.copytree('generated_content', f"{backup_dir}/generated_content", 
                              ignore=shutil.ignore_patterns('*.tmp', '*.log'))
            
            logger.info(f"تم إنشاء نسخة احتياطية: {backup_dir}")
            
            # حذف النسخ الاحتياطية الأقدم من 30 يوم
            if os.path.exists('backups'):
                subprocess.run([
                    'find', 'backups', '-type', 'd', '-name', 'backup_*',
                    '-mtime', '+30', '-exec', 'rm', '-rf', '{}', '+'
                ], check=False)
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء النسخة الاحتياطية: {e}")
    
    def save_cycle_stats(self, stats):
        """حفظ إحصائيات الدورة"""
        try:
            import json
            
            stats_file = f"cycle_stats_{datetime.now().strftime('%Y%m%d')}.json"
            
            # قراءة الإحصائيات الموجودة
            existing_stats = []
            if os.path.exists(stats_file):
                with open(stats_file, 'r', encoding='utf-8') as f:
                    existing_stats = json.load(f)
            
            # إضافة الإحصائيات الجديدة
            existing_stats.append(stats)
            
            # حفظ الإحصائيات
            with open(stats_file, 'w', encoding='utf-8') as f:
                json.dump(existing_stats, f, ensure_ascii=False, indent=2)
            
        except Exception as e:
            logger.error(f"خطأ في حفظ إحصائيات الدورة: {e}")
    
    def setup_schedule(self):
        """إعداد جدولة المهام"""
        logger.info("إعداد جدولة المهام...")
        
        # دورة تحديث كاملة كل ساعة
        schedule.every().hour.do(self.full_update_cycle)
        
        # تحديث سريع لـ RSS كل 15 دقيقة
        schedule.every(15).minutes.do(self.quick_rss_update)
        
        # مهام الصيانة اليومية في الساعة 2:00 صباحاً
        schedule.every().day.at("02:00").do(self.daily_maintenance)
        
        # تحديث API مرتين يومياً (في الصباح والمساء)
        schedule.every().day.at("08:00").do(self.collect_api_data)
        schedule.every().day.at("20:00").do(self.collect_api_data)
        
        logger.info("تم إعداد الجدولة بنجاح")
        logger.info("المهام المجدولة:")
        logger.info("- دورة تحديث كاملة: كل ساعة")
        logger.info("- تحديث سريع RSS: كل 15 دقيقة")
        logger.info("- تحديث API: 8:00 و 20:00 يومياً")
        logger.info("- مهام الصيانة: 2:00 صباحاً يومياً")
    
    def run(self):
        """تشغيل الجدولة"""
        logger.info("بدء تشغيل نظام الجدولة")
        
        # إعداد الجدولة
        self.setup_schedule()
        
        # تشغيل دورة أولية
        logger.info("تشغيل دورة تحديث أولية...")
        self.full_update_cycle()
        
        # حلقة الجدولة الرئيسية
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(60)  # فحص كل دقيقة
                
            except KeyboardInterrupt:
                logger.info("تم إيقاف النظام بواسطة المستخدم")
                break
            except Exception as e:
                logger.error(f"خطأ في حلقة الجدولة: {e}")
                time.sleep(60)
        
        logger.info("تم إيقاف نظام الجدولة")

def main():
    """الدالة الرئيسية"""
    print("=== نظام جدولة أتمتة المحتوى الرياضي ===")
    print("للإيقاف اضغط Ctrl+C")
    print()
    
    # إنشاء المجلدات المطلوبة
    os.makedirs('generated_content/articles', exist_ok=True)
    os.makedirs('generated_content/matches', exist_ok=True)
    os.makedirs('generated_content/summaries', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    
    # تشغيل الجدولة
    scheduler = SportsScheduler()
    scheduler.run()

if __name__ == "__main__":
    main()
