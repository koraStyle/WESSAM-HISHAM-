import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert.jsx'
import { 
  Activity, 
  FileText, 
  Calendar, 
  TrendingUp, 
  Users, 
  Globe, 
  RefreshCw, 
  Settings,
  BarChart3,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  Pause
} from 'lucide-react'
import './App.css'

function App() {
  const [systemStatus, setSystemStatus] = useState('running')
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [stats, setStats] = useState({
    totalArticles: 0,
    todayArticles: 0,
    totalMatches: 0,
    todayMatches: 0,
    activeSources: 0,
    totalSources: 0
  })

  // محاكاة جلب البيانات
  useEffect(() => {
    const fetchStats = () => {
      setStats({
        totalArticles: 1247,
        todayArticles: 23,
        totalMatches: 156,
        todayMatches: 8,
        activeSources: 6,
        totalSources: 8
      })
    }

    fetchStats()
    const interval = setInterval(fetchStats, 30000) // تحديث كل 30 ثانية

    return () => clearInterval(interval)
  }, [])

  const handleSystemToggle = () => {
    setSystemStatus(systemStatus === 'running' ? 'paused' : 'running')
  }

  const handleManualUpdate = () => {
    setLastUpdate(new Date())
    // هنا يمكن إضافة منطق التحديث اليدوي
  }

  const recentArticles = [
    {
      id: 1,
      title: "ريال مدريد يفوز على برشلونة في الكلاسيكو",
      source: "King Fut",
      time: "منذ 15 دقيقة",
      status: "published"
    },
    {
      id: 2,
      title: "محمد صلاح يسجل هدفين في فوز ليفربول",
      source: "Sport360",
      time: "منذ 30 دقيقة",
      status: "published"
    },
    {
      id: 3,
      title: "الأهلي يتأهل لنهائي دوري أبطال أفريقيا",
      source: "BBC Sport Arabic",
      time: "منذ ساعة",
      status: "pending"
    }
  ]

  const upcomingMatches = [
    {
      id: 1,
      homeTeam: "مانشستر سيتي",
      awayTeam: "أرسنال",
      league: "الدوري الإنجليزي",
      time: "18:00",
      date: "اليوم"
    },
    {
      id: 2,
      homeTeam: "الأهلي",
      awayTeam: "الزمالك",
      league: "الدوري المصري",
      time: "20:00",
      date: "غداً"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              لوحة إدارة المحتوى الرياضي
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-1">
              آخر تحديث: {lastUpdate.toLocaleString('ar-EG')}
            </p>
          </div>
          
          <div className="flex gap-3">
            <Button 
              onClick={handleManualUpdate}
              variant="outline" 
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              تحديث يدوي
            </Button>
            
            <Button 
              onClick={handleSystemToggle}
              variant={systemStatus === 'running' ? 'destructive' : 'default'}
              className="flex items-center gap-2"
            >
              {systemStatus === 'running' ? (
                <>
                  <Pause className="h-4 w-4" />
                  إيقاف النظام
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  تشغيل النظام
                </>
              )}
            </Button>
          </div>
        </div>

        {/* System Status Alert */}
        <Alert className={systemStatus === 'running' ? 'border-green-200 bg-green-50' : 'border-yellow-200 bg-yellow-50'}>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>حالة النظام</AlertTitle>
          <AlertDescription>
            النظام حالياً {systemStatus === 'running' ? 'يعمل بشكل طبيعي' : 'متوقف مؤقتاً'}
            {systemStatus === 'running' && ' - التحديث التلقائي كل 30 دقيقة'}
          </AlertDescription>
        </Alert>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">إجمالي المقالات</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalArticles.toLocaleString('ar-EG')}</div>
              <p className="text-xs text-muted-foreground">
                +{stats.todayArticles} اليوم
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المباريات</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalMatches.toLocaleString('ar-EG')}</div>
              <p className="text-xs text-muted-foreground">
                {stats.todayMatches} مباراة اليوم
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">المصادر النشطة</CardTitle>
              <Globe className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeSources}/{stats.totalSources}</div>
              <Progress value={(stats.activeSources / stats.totalSources) * 100} className="mt-2" />
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">معدل النجاح</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">94%</div>
              <Progress value={94} className="mt-2" />
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="articles">المقالات</TabsTrigger>
            <TabsTrigger value="matches">المباريات</TabsTrigger>
            <TabsTrigger value="settings">الإعدادات</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Articles */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    أحدث المقالات
                  </CardTitle>
                  <CardDescription>
                    آخر المقالات التي تم جمعها ومعالجتها
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentArticles.map((article) => (
                    <div key={article.id} className="flex items-start justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{article.title}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {article.source}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {article.time}
                          </span>
                        </div>
                      </div>
                      <Badge 
                        variant={article.status === 'published' ? 'default' : 'secondary'}
                        className="mr-2"
                      >
                        {article.status === 'published' ? 'منشور' : 'في الانتظار'}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Upcoming Matches */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    المباريات القادمة
                  </CardTitle>
                  <CardDescription>
                    المباريات المجدولة للأيام القادمة
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {upcomingMatches.map((match) => (
                    <div key={match.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium text-sm">
                          {match.homeTeam} ضد {match.awayTeam}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {match.league}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {match.date} - {match.time}
                          </span>
                        </div>
                      </div>
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="articles">
            <Card>
              <CardHeader>
                <CardTitle>إدارة المقالات</CardTitle>
                <CardDescription>
                  عرض وإدارة جميع المقالات المجمعة من المصادر المختلفة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    سيتم عرض قائمة مفصلة بجميع المقالات هنا
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="matches">
            <Card>
              <CardHeader>
                <CardTitle>إدارة المباريات</CardTitle>
                <CardDescription>
                  عرض وإدارة بيانات المباريات والنتائج
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    سيتم عرض قائمة مفصلة بجميع المباريات هنا
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>إعدادات النظام</CardTitle>
                <CardDescription>
                  تكوين مصادر البيانات وإعدادات الأتمتة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    سيتم عرض إعدادات النظام هنا
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App
