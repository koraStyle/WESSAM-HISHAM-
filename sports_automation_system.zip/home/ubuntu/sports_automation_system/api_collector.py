#!/usr/bin/env python3
"""
API Football Data Collector
جامع بيانات كرة القدم من API-Football
"""

import requests
import json
import sqlite3
from datetime import datetime, timezone, timedelta
import logging
import time
from typing import List, Dict, Optional
import os

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sports_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class APIFootballCollector:
    """جامع بيانات كرة القدم من API-Football"""
    
    def __init__(self, api_key: str = None, db_path: str = "sports_content.db"):
        self.api_key = api_key or os.getenv('API_FOOTBALL_KEY', 'YOUR_API_KEY_HERE')
        self.db_path = db_path
        self.base_url = "https://v3.football.api-sports.io"
        self.headers = {
            'X-RapidAPI-Key': self.api_key,
            'X-RapidAPI-Host': 'v3.football.api-sports.io'
        }
        self.init_database()
        
        # معرفات الدوريات الرئيسية
        self.main_leagues = {
            'premier_league': 39,      # الدوري الإنجليزي الممتاز
            'la_liga': 140,           # الليجا الإسبانية
            'bundesliga': 78,         # الدوري الألماني
            'serie_a': 135,           # الدوري الإيطالي
            'ligue_1': 61,            # الدوري الفرنسي
            'champions_league': 2,     # دوري أبطال أوروبا
            'europa_league': 3,        # الدوري الأوروبي
            'world_cup': 1,           # كأس العالم
            'egyptian_league': 233,    # الدوري المصري
            'saudi_league': 307,       # الدوري السعودي
            'uae_league': 301,         # دوري الإمارات
        }
    
    def init_database(self):
        """إنشاء جداول قاعدة البيانات للبيانات الرياضية"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # جدول المباريات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS matches (
                    id INTEGER PRIMARY KEY,
                    fixture_id INTEGER UNIQUE,
                    league_id INTEGER,
                    league_name TEXT,
                    season INTEGER,
                    match_date DATETIME,
                    status TEXT,
                    home_team TEXT,
                    away_team TEXT,
                    home_score INTEGER,
                    away_score INTEGER,
                    venue TEXT,
                    referee TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # جدول ترتيب الدوريات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS standings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    league_id INTEGER,
                    league_name TEXT,
                    season INTEGER,
                    team_name TEXT,
                    position INTEGER,
                    points INTEGER,
                    played INTEGER,
                    wins INTEGER,
                    draws INTEGER,
                    losses INTEGER,
                    goals_for INTEGER,
                    goals_against INTEGER,
                    goal_difference INTEGER,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(league_id, season, team_name)
                )
            ''')
            
            # جدول الإحصائيات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS player_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    player_id INTEGER,
                    player_name TEXT,
                    team_name TEXT,
                    league_id INTEGER,
                    season INTEGER,
                    goals INTEGER DEFAULT 0,
                    assists INTEGER DEFAULT 0,
                    appearances INTEGER DEFAULT 0,
                    yellow_cards INTEGER DEFAULT 0,
                    red_cards INTEGER DEFAULT 0,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(player_id, league_id, season)
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("تم إنشاء جداول قاعدة البيانات بنجاح")
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء جداول قاعدة البيانات: {e}")
    
    def make_api_request(self, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """إجراء طلب API مع معالجة الأخطاء"""
        try:
            url = f"{self.base_url}/{endpoint}"
            response = requests.get(url, headers=self.headers, params=params, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('errors'):
                    logger.error(f"خطأ في API: {data['errors']}")
                    return None
                return data
            elif response.status_code == 429:
                logger.warning("تم تجاوز حد الطلبات، انتظار...")
                time.sleep(60)  # انتظار دقيقة
                return None
            else:
                logger.error(f"خطأ HTTP {response.status_code}: {response.text}")
                return None
                
        except requests.RequestException as e:
            logger.error(f"خطأ في الاتصال بـ API: {e}")
            return None
        except Exception as e:
            logger.error(f"خطأ غير متوقع في API: {e}")
            return None
    
    def fetch_fixtures(self, league_id: int, date: str = None) -> List[Dict]:
        """جلب مباريات دوري معين"""
        if not date:
            date = datetime.now().strftime('%Y-%m-%d')
        
        params = {
            'league': league_id,
            'date': date,
            'season': datetime.now().year
        }
        
        data = self.make_api_request('fixtures', params)
        if not data or not data.get('response'):
            return []
        
        fixtures = []
        for fixture in data['response']:
            try:
                match_data = {
                    'fixture_id': fixture['fixture']['id'],
                    'league_id': league_id,
                    'league_name': fixture['league']['name'],
                    'season': fixture['league']['season'],
                    'match_date': fixture['fixture']['date'],
                    'status': fixture['fixture']['status']['short'],
                    'home_team': fixture['teams']['home']['name'],
                    'away_team': fixture['teams']['away']['name'],
                    'home_score': fixture['goals']['home'],
                    'away_score': fixture['goals']['away'],
                    'venue': fixture['fixture']['venue']['name'] if fixture['fixture']['venue'] else None,
                    'referee': fixture['fixture']['referee']
                }
                fixtures.append(match_data)
                
            except KeyError as e:
                logger.error(f"خطأ في بيانات المباراة: {e}")
                continue
        
        logger.info(f"تم جلب {len(fixtures)} مباراة من الدوري {league_id}")
        return fixtures
    
    def fetch_standings(self, league_id: int, season: int = None) -> List[Dict]:
        """جلب ترتيب دوري معين"""
        if not season:
            season = datetime.now().year
        
        params = {
            'league': league_id,
            'season': season
        }
        
        data = self.make_api_request('standings', params)
        if not data or not data.get('response'):
            return []
        
        standings = []
        try:
            league_standings = data['response'][0]['league']['standings'][0]
            
            for team in league_standings:
                standing_data = {
                    'league_id': league_id,
                    'league_name': data['response'][0]['league']['name'],
                    'season': season,
                    'team_name': team['team']['name'],
                    'position': team['rank'],
                    'points': team['points'],
                    'played': team['all']['played'],
                    'wins': team['all']['win'],
                    'draws': team['all']['draw'],
                    'losses': team['all']['lose'],
                    'goals_for': team['all']['goals']['for'],
                    'goals_against': team['all']['goals']['against'],
                    'goal_difference': team['goalsDiff']
                }
                standings.append(standing_data)
                
        except (KeyError, IndexError) as e:
            logger.error(f"خطأ في بيانات الترتيب: {e}")
            return []
        
        logger.info(f"تم جلب ترتيب الدوري {league_id}")
        return standings
    
    def save_fixtures(self, fixtures: List[Dict]) -> int:
        """حفظ المباريات في قاعدة البيانات"""
        if not fixtures:
            return 0
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            saved_count = 0
            for fixture in fixtures:
                try:
                    cursor.execute('''
                        INSERT OR REPLACE INTO matches 
                        (fixture_id, league_id, league_name, season, match_date, 
                         status, home_team, away_team, home_score, away_score, 
                         venue, referee, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        fixture['fixture_id'],
                        fixture['league_id'],
                        fixture['league_name'],
                        fixture['season'],
                        fixture['match_date'],
                        fixture['status'],
                        fixture['home_team'],
                        fixture['away_team'],
                        fixture['home_score'],
                        fixture['away_score'],
                        fixture['venue'],
                        fixture['referee'],
                        datetime.now()
                    ))
                    saved_count += 1
                    
                except Exception as e:
                    logger.error(f"خطأ في حفظ مباراة: {e}")
                    continue
            
            conn.commit()
            conn.close()
            
            logger.info(f"تم حفظ {saved_count} مباراة")
            return saved_count
            
        except Exception as e:
            logger.error(f"خطأ في حفظ المباريات: {e}")
            return 0
    
    def save_standings(self, standings: List[Dict]) -> int:
        """حفظ ترتيب الدوري في قاعدة البيانات"""
        if not standings:
            return 0
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            saved_count = 0
            for standing in standings:
                try:
                    cursor.execute('''
                        INSERT OR REPLACE INTO standings 
                        (league_id, league_name, season, team_name, position, 
                         points, played, wins, draws, losses, goals_for, 
                         goals_against, goal_difference, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        standing['league_id'],
                        standing['league_name'],
                        standing['season'],
                        standing['team_name'],
                        standing['position'],
                        standing['points'],
                        standing['played'],
                        standing['wins'],
                        standing['draws'],
                        standing['losses'],
                        standing['goals_for'],
                        standing['goals_against'],
                        standing['goal_difference'],
                        datetime.now()
                    ))
                    saved_count += 1
                    
                except Exception as e:
                    logger.error(f"خطأ في حفظ ترتيب فريق: {e}")
                    continue
            
            conn.commit()
            conn.close()
            
            logger.info(f"تم حفظ ترتيب {saved_count} فريق")
            return saved_count
            
        except Exception as e:
            logger.error(f"خطأ في حفظ الترتيب: {e}")
            return 0
    
    def collect_daily_data(self) -> Dict[str, int]:
        """جمع البيانات اليومية من جميع الدوريات"""
        results = {
            'fixtures': 0,
            'standings': 0
        }
        
        logger.info("بدء جمع البيانات اليومية")
        
        # جلب مباريات اليوم
        today = datetime.now().strftime('%Y-%m-%d')
        
        for league_name, league_id in self.main_leagues.items():
            try:
                # جلب المباريات
                fixtures = self.fetch_fixtures(league_id, today)
                saved_fixtures = self.save_fixtures(fixtures)
                results['fixtures'] += saved_fixtures
                
                # جلب الترتيب (مرة واحدة أسبوعياً فقط لتوفير الطلبات)
                if datetime.now().weekday() == 0:  # الاثنين
                    standings = self.fetch_standings(league_id)
                    saved_standings = self.save_standings(standings)
                    results['standings'] += saved_standings
                
                # انتظار قصير بين الطلبات
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"خطأ في معالجة دوري {league_name}: {e}")
                continue
        
        logger.info(f"انتهى جمع البيانات. المباريات: {results['fixtures']}, الترتيب: {results['standings']}")
        return results

def main():
    """الدالة الرئيسية"""
    # تحقق من وجود API key
    api_key = os.getenv('API_FOOTBALL_KEY')
    if not api_key or api_key == 'YOUR_API_KEY_HERE':
        print("تحذير: لم يتم تعيين API key. يرجى تعيين متغير البيئة API_FOOTBALL_KEY")
        print("يمكنك الحصول على API key مجاني من: https://www.api-football.com/")
        return
    
    collector = APIFootballCollector(api_key)
    
    # جمع البيانات اليومية
    results = collector.collect_daily_data()
    
    # طباعة النتائج
    print("\n=== تقرير جمع بيانات كرة القدم ===")
    print(f"المباريات المحدثة: {results['fixtures']}")
    print(f"جداول الترتيب المحدثة: {results['standings']}")

if __name__ == "__main__":
    main()
