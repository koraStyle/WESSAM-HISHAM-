#!/usr/bin/env python3
"""
RSS Feed Collector for Sports Content Automation
جامع تغذية RSS لأتمتة المحتوى الرياضي
"""

import feedparser
import requests
import json
import sqlite3
from datetime import datetime, timezone
import hashlib
import os
from typing import List, Dict, Optional
import logging

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sports_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RSSCollector:
    """جامع المحتوى من مصادر RSS"""
    
    def __init__(self, db_path: str = "sports_content.db"):
        self.db_path = db_path
        self.init_database()
        
        # قائمة مصادر RSS الرياضية
        self.rss_sources = {
            'king_fut': {
                'url': 'https://feeds.feedburner.com/KingFut',
                'name': 'King Fut',
                'language': 'ar',
                'category': 'football'
            },
            'sport360': {
                'url': 'https://sport360.com/feed',
                'name': 'Sport360',
                'language': 'ar',
                'category': 'general_sports'
            },
            'doha_news_sports': {
                'url': 'https://dohanews.co/category/sports/feed',
                'name': 'Doha News Sports',
                'language': 'ar',
                'category': 'general_sports'
            },
            'peninsula_qatar_sports': {
                'url': 'https://thepeninsulaqatar.com/category/sports/feed',
                'name': 'The Peninsula Qatar Sports',
                'language': 'ar',
                'category': 'general_sports'
            },
            'bbc_sport': {
                'url': 'https://feeds.bbci.co.uk/sport/rss.xml',
                'name': 'BBC Sport',
                'language': 'en',
                'category': 'general_sports'
            },
            'espn': {
                'url': 'https://www.espn.com/espn/rss/news',
                'name': 'ESPN',
                'language': 'en',
                'category': 'general_sports'
            }
        }
    
    def init_database(self):
        """إنشاء قاعدة البيانات والجداول"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # جدول المقالات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS articles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    content TEXT,
                    summary TEXT,
                    source_url TEXT UNIQUE,
                    source_name TEXT,
                    publication_date DATETIME,
                    category TEXT,
                    language TEXT,
                    hash TEXT UNIQUE,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    processed BOOLEAN DEFAULT FALSE
                )
            ''')
            
            # جدول المصادر
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    url TEXT UNIQUE,
                    last_updated DATETIME,
                    active BOOLEAN DEFAULT TRUE
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("تم إنشاء قاعدة البيانات بنجاح")
            
        except Exception as e:
            logger.error(f"خطأ في إنشاء قاعدة البيانات: {e}")
    
    def generate_content_hash(self, title: str, content: str) -> str:
        """إنشاء hash فريد للمحتوى لتجنب التكرار"""
        content_string = f"{title}{content}"
        return hashlib.md5(content_string.encode('utf-8')).hexdigest()
    
    def fetch_rss_feed(self, source_key: str) -> List[Dict]:
        """جلب المحتوى من مصدر RSS محدد"""
        source = self.rss_sources.get(source_key)
        if not source:
            logger.error(f"مصدر غير موجود: {source_key}")
            return []
        
        try:
            logger.info(f"جلب المحتوى من: {source['name']}")
            
            # إعداد headers لتجنب الحظر
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            
            # جلب RSS feed
            response = requests.get(source['url'], headers=headers, timeout=30)
            response.raise_for_status()
            
            feed = feedparser.parse(response.content)
            
            if feed.bozo:
                logger.warning(f"تحذير: مشكلة في تحليل RSS من {source['name']}")
            
            articles = []
            for entry in feed.entries[:10]:  # أخذ أحدث 10 مقالات
                try:
                    # تنظيف وتنسيق البيانات
                    title = entry.get('title', '').strip()
                    summary = entry.get('summary', '').strip()
                    link = entry.get('link', '').strip()
                    
                    if not title or not link:
                        continue
                    
                    # تحويل تاريخ النشر
                    pub_date = None
                    if hasattr(entry, 'published_parsed') and entry.published_parsed:
                        pub_date = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
                    elif hasattr(entry, 'updated_parsed') and entry.updated_parsed:
                        pub_date = datetime(*entry.updated_parsed[:6], tzinfo=timezone.utc)
                    
                    # إنشاء hash للمحتوى
                    content_hash = self.generate_content_hash(title, summary)
                    
                    article = {
                        'title': title,
                        'summary': summary,
                        'source_url': link,
                        'source_name': source['name'],
                        'publication_date': pub_date,
                        'category': source['category'],
                        'language': source['language'],
                        'hash': content_hash
                    }
                    
                    articles.append(article)
                    
                except Exception as e:
                    logger.error(f"خطأ في معالجة مقال من {source['name']}: {e}")
                    continue
            
            logger.info(f"تم جلب {len(articles)} مقال من {source['name']}")
            return articles
            
        except requests.RequestException as e:
            logger.error(f"خطأ في الاتصال بـ {source['name']}: {e}")
            return []
        except Exception as e:
            logger.error(f"خطأ غير متوقع مع {source['name']}: {e}")
            return []
    
    def save_articles(self, articles: List[Dict]) -> int:
        """حفظ المقالات في قاعدة البيانات"""
        if not articles:
            return 0
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            new_articles = 0
            for article in articles:
                try:
                    cursor.execute('''
                        INSERT OR IGNORE INTO articles 
                        (title, summary, source_url, source_name, publication_date, 
                         category, language, hash)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        article['title'],
                        article['summary'],
                        article['source_url'],
                        article['source_name'],
                        article['publication_date'],
                        article['category'],
                        article['language'],
                        article['hash']
                    ))
                    
                    if cursor.rowcount > 0:
                        new_articles += 1
                        
                except sqlite3.IntegrityError:
                    # المقال موجود مسبقاً
                    continue
                except Exception as e:
                    logger.error(f"خطأ في حفظ مقال: {e}")
                    continue
            
            conn.commit()
            conn.close()
            
            logger.info(f"تم حفظ {new_articles} مقال جديد")
            return new_articles
            
        except Exception as e:
            logger.error(f"خطأ في حفظ المقالات: {e}")
            return 0
    
    def collect_all_sources(self) -> Dict[str, int]:
        """جمع المحتوى من جميع المصادر"""
        results = {}
        total_new_articles = 0
        
        logger.info("بدء جمع المحتوى من جميع المصادر")
        
        for source_key in self.rss_sources.keys():
            try:
                articles = self.fetch_rss_feed(source_key)
                new_count = self.save_articles(articles)
                results[source_key] = new_count
                total_new_articles += new_count
                
            except Exception as e:
                logger.error(f"خطأ في معالجة مصدر {source_key}: {e}")
                results[source_key] = 0
        
        logger.info(f"انتهى جمع المحتوى. إجمالي المقالات الجديدة: {total_new_articles}")
        return results
    
    def get_recent_articles(self, limit: int = 20) -> List[Dict]:
        """الحصول على أحدث المقالات"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT title, summary, source_url, source_name, 
                       publication_date, category, language
                FROM articles 
                ORDER BY publication_date DESC, created_at DESC 
                LIMIT ?
            ''', (limit,))
            
            articles = []
            for row in cursor.fetchall():
                articles.append({
                    'title': row[0],
                    'summary': row[1],
                    'source_url': row[2],
                    'source_name': row[3],
                    'publication_date': row[4],
                    'category': row[5],
                    'language': row[6]
                })
            
            conn.close()
            return articles
            
        except Exception as e:
            logger.error(f"خطأ في جلب المقالات الحديثة: {e}")
            return []

def main():
    """الدالة الرئيسية"""
    collector = RSSCollector()
    
    # جمع المحتوى من جميع المصادر
    results = collector.collect_all_sources()
    
    # طباعة النتائج
    print("\n=== تقرير جمع المحتوى ===")
    for source, count in results.items():
        print(f"{source}: {count} مقال جديد")
    
    # عرض أحدث المقالات
    recent_articles = collector.get_recent_articles(5)
    print(f"\n=== أحدث {len(recent_articles)} مقالات ===")
    for i, article in enumerate(recent_articles, 1):
        print(f"{i}. {article['title'][:80]}...")
        print(f"   المصدر: {article['source_name']}")
        print(f"   التاريخ: {article['publication_date']}")
        print()

if __name__ == "__main__":
    main()
