#!/usr/bin/env python3
"""
Content Generator for Sports Automation System
مولد المحتوى لنظام أتمتة المحتوى الرياضي
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import logging
import os
from jinja2 import Template
import markdown
import re

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('sports_automation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ContentGenerator:
    """مولد المحتوى الرياضي"""
    
    def __init__(self, db_path: str = "sports_content.db", output_dir: str = "generated_content"):
        self.db_path = db_path
        self.output_dir = output_dir
        self.create_output_directory()
        
        # قوالب المحتوى
        self.templates = {
            'news_article': self.get_news_template(),
            'match_report': self.get_match_report_template(),
            'standings_update': self.get_standings_template(),
            'daily_summary': self.get_daily_summary_template()
        }
    
    def create_output_directory(self):
        """إنشاء مجلدات الإخراج"""
        directories = [
            self.output_dir,
            f"{self.output_dir}/articles",
            f"{self.output_dir}/matches",
            f"{self.output_dir}/standings",
            f"{self.output_dir}/summaries"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
    
    def get_news_template(self) -> str:
        """قالب المقالات الإخبارية"""
        return """---
title: "{{ title }}"
date: {{ publication_date }}
category: {{ category }}
source: {{ source_name }}
language: {{ language }}
tags: [{{ tags }}]
---

# {{ title }}

**المصدر:** [{{ source_name }}]({{ source_url }})  
**التاريخ:** {{ publication_date_formatted }}  
**التصنيف:** {{ category_arabic }}

## ملخص الخبر

{{ summary }}

{% if content %}
## التفاصيل

{{ content }}
{% endif %}

---

*تم إنشاء هذا المحتوى تلقائياً بواسطة نظام أتمتة المحتوى الرياضي*

**الكلمات المفتاحية:** {{ tags }}
"""
    
    def get_match_report_template(self) -> str:
        """قالب تقارير المباريات"""
        return """---
title: "{{ home_team }} {{ home_score }}-{{ away_score }} {{ away_team }}"
date: {{ match_date }}
category: "نتائج المباريات"
league: "{{ league_name }}"
status: "{{ status }}"
---

# {{ home_team }} {{ home_score }}-{{ away_score }} {{ away_team }}

## معلومات المباراة

| التفاصيل | القيمة |
|---------|-------|
| **البطولة** | {{ league_name }} |
| **التاريخ** | {{ match_date_formatted }} |
| **الملعب** | {{ venue or "غير محدد" }} |
| **الحكم** | {{ referee or "غير محدد" }} |
| **الحالة** | {{ status_arabic }} |

## النتيجة النهائية

<div class="match-result">
  <div class="team home">
    <h3>{{ home_team }}</h3>
    <div class="score">{{ home_score or 0 }}</div>
  </div>
  
  <div class="vs">VS</div>
  
  <div class="team away">
    <h3>{{ away_team }}</h3>
    <div class="score">{{ away_score or 0 }}</div>
  </div>
</div>

{% if status == 'FT' %}
## ملخص المباراة

انتهت مباراة {{ home_team }} ضد {{ away_team }} بنتيجة {{ home_score }}-{{ away_score }} 
{% if home_score > away_score %}
لصالح {{ home_team }}.
{% elif away_score > home_score %}
لصالح {{ away_team }}.
{% else %}
بالتعادل.
{% endif %}

{% endif %}

---

*تم إنشاء هذا التقرير تلقائياً بواسطة نظام أتمتة المحتوى الرياضي*
"""
    
    def get_standings_template(self) -> str:
        """قالب جداول الترتيب"""
        return """---
title: "ترتيب {{ league_name }} - الموسم {{ season }}"
date: {{ update_date }}
category: "جداول الترتيب"
league: "{{ league_name }}"
season: {{ season }}
---

# ترتيب {{ league_name }} - الموسم {{ season }}

**آخر تحديث:** {{ update_date_formatted }}

## الجدول الحالي

| المركز | الفريق | نقاط | لعب | فوز | تعادل | خسارة | له | عليه | الفارق |
|--------|-------|------|-----|-----|------|-------|----|----|-------|
{% for team in teams %}
| {{ team.position }} | **{{ team.team_name }}** | {{ team.points }} | {{ team.played }} | {{ team.wins }} | {{ team.draws }} | {{ team.losses }} | {{ team.goals_for }} | {{ team.goals_against }} | {{ team.goal_difference }} |
{% endfor %}

## إحصائيات سريعة

- **المتصدر:** {{ teams[0].team_name }} بـ {{ teams[0].points }} نقطة
- **أكثر الفرق تسجيلاً:** {{ top_scorer.team_name }} ({{ top_scorer.goals_for }} هدف)
- **أقل الفرق استقبالاً للأهداف:** {{ best_defense.team_name }} ({{ best_defense.goals_against }} هدف)

---

*تم إنشاء هذا الجدول تلقائياً بواسطة نظام أتمتة المحتوى الرياضي*
"""
    
    def get_daily_summary_template(self) -> str:
        """قالب الملخص اليومي"""
        return """---
title: "الملخص الرياضي اليومي - {{ date }}"
date: {{ date }}
category: "ملخص يومي"
---

# الملخص الرياضي اليومي
## {{ date_formatted }}

## أبرز الأخبار

{% for article in top_articles %}
### {{ loop.index }}. {{ article.title }}

{{ article.summary[:200] }}...

**المصدر:** {{ article.source_name }}  
[اقرأ المزيد]({{ article.source_url }})

---
{% endfor %}

## نتائج المباريات

{% if matches %}
| المباراة | النتيجة | البطولة |
|---------|---------|---------|
{% for match in matches %}
| {{ match.home_team }} vs {{ match.away_team }} | {{ match.home_score }}-{{ match.away_score }} | {{ match.league_name }} |
{% endfor %}
{% else %}
لا توجد مباريات اليوم.
{% endif %}

## إحصائيات اليوم

- **عدد الأخبار الجديدة:** {{ articles_count }}
- **عدد المباريات:** {{ matches_count }}
- **آخر تحديث:** {{ last_update }}

---

*تم إنشاء هذا الملخص تلقائياً بواسطة نظام أتمتة المحتوى الرياضي*
"""
    
    def clean_text(self, text: str) -> str:
        """تنظيف النص من HTML والرموز غير المرغوبة"""
        if not text:
            return ""
        
        # إزالة HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        
        # إزالة الرموز الخاصة
        text = re.sub(r'&[a-zA-Z]+;', '', text)
        
        # تنظيف المسافات الزائدة
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def format_date(self, date_str: str) -> str:
        """تنسيق التاريخ للعرض"""
        try:
            if isinstance(date_str, str):
                date_obj = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
            else:
                date_obj = date_str
            
            # تنسيق التاريخ بالعربية
            months = [
                'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
            ]
            
            day = date_obj.day
            month = months[date_obj.month - 1]
            year = date_obj.year
            
            return f"{day} {month} {year}"
            
        except Exception as e:
            logger.error(f"خطأ في تنسيق التاريخ: {e}")
            return str(date_str)
    
    def get_category_arabic(self, category: str) -> str:
        """ترجمة التصنيفات إلى العربية"""
        categories = {
            'football': 'كرة القدم',
            'general_sports': 'رياضة عامة',
            'basketball': 'كرة السلة',
            'tennis': 'تنس',
            'news': 'أخبار',
            'analysis': 'تحليلات'
        }
        return categories.get(category, category)
    
    def get_status_arabic(self, status: str) -> str:
        """ترجمة حالة المباراة إلى العربية"""
        statuses = {
            'FT': 'انتهت',
            'LIVE': 'مباشر',
            'NS': 'لم تبدأ',
            'HT': 'الشوط الأول',
            'PST': 'مؤجلة',
            'CANC': 'ملغية'
        }
        return statuses.get(status, status)
    
    def generate_news_articles(self, limit: int = 10) -> int:
        """توليد مقالات إخبارية"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT title, summary, source_url, source_name, 
                       publication_date, category, language
                FROM articles 
                WHERE processed = FALSE
                ORDER BY publication_date DESC 
                LIMIT ?
            ''', (limit,))
            
            articles = cursor.fetchall()
            generated_count = 0
            
            for article in articles:
                try:
                    title, summary, source_url, source_name, pub_date, category, language = article
                    
                    # تنظيف البيانات
                    title = self.clean_text(title)
                    summary = self.clean_text(summary)
                    
                    # إعداد البيانات للقالب
                    template_data = {
                        'title': title,
                        'summary': summary,
                        'source_url': source_url,
                        'source_name': source_name,
                        'publication_date': pub_date,
                        'publication_date_formatted': self.format_date(pub_date) if pub_date else 'غير محدد',
                        'category': category,
                        'category_arabic': self.get_category_arabic(category),
                        'language': language,
                        'tags': f"{category}, أخبار رياضية, {source_name}",
                        'content': ''  # يمكن إضافة محتوى إضافي هنا
                    }
                    
                    # توليد المحتوى
                    template = Template(self.templates['news_article'])
                    content = template.render(**template_data)
                    
                    # حفظ الملف
                    filename = f"article_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{generated_count + 1}.md"
                    filepath = os.path.join(self.output_dir, 'articles', filename)
                    
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    
                    generated_count += 1
                    logger.info(f"تم إنشاء مقال: {filename}")
                    
                except Exception as e:
                    logger.error(f"خطأ في توليد مقال: {e}")
                    continue
            
            # تحديث حالة المعالجة
            if generated_count > 0:
                cursor.execute('''
                    UPDATE articles 
                    SET processed = TRUE 
                    WHERE id IN (
                        SELECT id FROM articles 
                        WHERE processed = FALSE 
                        ORDER BY publication_date DESC 
                        LIMIT ?
                    )
                ''', (generated_count,))
                conn.commit()
            
            conn.close()
            logger.info(f"تم توليد {generated_count} مقال إخباري")
            return generated_count
            
        except Exception as e:
            logger.error(f"خطأ في توليد المقالات الإخبارية: {e}")
            return 0
    
    def generate_match_reports(self, days_back: int = 1) -> int:
        """توليد تقارير المباريات"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # جلب المباريات من آخر يوم/أيام
            start_date = (datetime.now() - timedelta(days=days_back)).strftime('%Y-%m-%d')
            
            cursor.execute('''
                SELECT fixture_id, league_name, season, match_date, status,
                       home_team, away_team, home_score, away_score, venue, referee
                FROM matches 
                WHERE DATE(match_date) >= ? AND status = 'FT'
                ORDER BY match_date DESC
            ''', (start_date,))
            
            matches = cursor.fetchall()
            generated_count = 0
            
            for match in matches:
                try:
                    (fixture_id, league_name, season, match_date, status,
                     home_team, away_team, home_score, away_score, venue, referee) = match
                    
                    # إعداد البيانات للقالب
                    template_data = {
                        'fixture_id': fixture_id,
                        'league_name': league_name,
                        'season': season,
                        'match_date': match_date,
                        'match_date_formatted': self.format_date(match_date),
                        'status': status,
                        'status_arabic': self.get_status_arabic(status),
                        'home_team': home_team,
                        'away_team': away_team,
                        'home_score': home_score or 0,
                        'away_score': away_score or 0,
                        'venue': venue,
                        'referee': referee
                    }
                    
                    # توليد المحتوى
                    template = Template(self.templates['match_report'])
                    content = template.render(**template_data)
                    
                    # حفظ الملف
                    filename = f"match_{fixture_id}_{home_team}_{away_team}.md"
                    filename = re.sub(r'[^\w\-_.]', '_', filename)  # تنظيف اسم الملف
                    filepath = os.path.join(self.output_dir, 'matches', filename)
                    
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)
                    
                    generated_count += 1
                    logger.info(f"تم إنشاء تقرير مباراة: {filename}")
                    
                except Exception as e:
                    logger.error(f"خطأ في توليد تقرير مباراة: {e}")
                    continue
            
            conn.close()
            logger.info(f"تم توليد {generated_count} تقرير مباراة")
            return generated_count
            
        except Exception as e:
            logger.error(f"خطأ في توليد تقارير المباريات: {e}")
            return 0
    
    def generate_daily_summary(self) -> bool:
        """توليد الملخص اليومي"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            today = datetime.now().strftime('%Y-%m-%d')
            
            # جلب أهم الأخبار
            cursor.execute('''
                SELECT title, summary, source_name, source_url
                FROM articles 
                WHERE DATE(created_at) = ?
                ORDER BY created_at DESC 
                LIMIT 5
            ''', (today,))
            
            top_articles = []
            for row in cursor.fetchall():
                top_articles.append({
                    'title': row[0],
                    'summary': row[1],
                    'source_name': row[2],
                    'source_url': row[3]
                })
            
            # جلب مباريات اليوم
            cursor.execute('''
                SELECT home_team, away_team, home_score, away_score, league_name
                FROM matches 
                WHERE DATE(match_date) = ? AND status = 'FT'
                ORDER BY match_date DESC
            ''', (today,))
            
            matches = []
            for row in cursor.fetchall():
                matches.append({
                    'home_team': row[0],
                    'away_team': row[1],
                    'home_score': row[2] or 0,
                    'away_score': row[3] or 0,
                    'league_name': row[4]
                })
            
            # إحصائيات
            cursor.execute('SELECT COUNT(*) FROM articles WHERE DATE(created_at) = ?', (today,))
            articles_count = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM matches WHERE DATE(match_date) = ?', (today,))
            matches_count = cursor.fetchone()[0]
            
            conn.close()
            
            # إعداد البيانات للقالب
            template_data = {
                'date': today,
                'date_formatted': self.format_date(today),
                'top_articles': top_articles,
                'matches': matches,
                'articles_count': articles_count,
                'matches_count': matches_count,
                'last_update': datetime.now().strftime('%H:%M')
            }
            
            # توليد المحتوى
            template = Template(self.templates['daily_summary'])
            content = template.render(**template_data)
            
            # حفظ الملف
            filename = f"daily_summary_{today}.md"
            filepath = os.path.join(self.output_dir, 'summaries', filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"تم إنشاء الملخص اليومي: {filename}")
            return True
            
        except Exception as e:
            logger.error(f"خطأ في توليد الملخص اليومي: {e}")
            return False
    
    def generate_all_content(self) -> Dict[str, int]:
        """توليد جميع أنواع المحتوى"""
        results = {}
        
        logger.info("بدء توليد المحتوى")
        
        # توليد المقالات الإخبارية
        results['articles'] = self.generate_news_articles()
        
        # توليد تقارير المباريات
        results['matches'] = self.generate_match_reports()
        
        # توليد الملخص اليومي
        results['daily_summary'] = 1 if self.generate_daily_summary() else 0
        
        logger.info("انتهى توليد المحتوى")
        return results

def main():
    """الدالة الرئيسية"""
    generator = ContentGenerator()
    
    # توليد جميع أنواع المحتوى
    results = generator.generate_all_content()
    
    # طباعة النتائج
    print("\n=== تقرير توليد المحتوى ===")
    print(f"المقالات الإخبارية: {results['articles']}")
    print(f"تقارير المباريات: {results['matches']}")
    print(f"الملخص اليومي: {results['daily_summary']}")
    
    total = sum(results.values())
    print(f"إجمالي الملفات المولدة: {total}")

if __name__ == "__main__":
    main()
