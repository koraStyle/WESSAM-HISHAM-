#!/usr/bin/env python3
"""
Main Entry Point for Sports Content Automation System
نقطة الدخول الرئيسية لنظام أتمتة المحتوى الرياضي
"""

import argparse
import sys
import os
import logging
import subprocess
import signal
import time
from datetime import datetime

# إعداد نظام التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('main.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SportsAutomationSystem:
    """النظام الرئيسي لأتمتة المحتوى الرياضي"""
    
    def __init__(self):
        self.processes = {}
        self.running = True
        
        # إعداد معالج الإشارات
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        """معالج إشارات الإغلاق"""
        logger.info(f"تم استلام إشارة {signum}، جاري إيقاف النظام...")
        self.stop_all_processes()
        sys.exit(0)
    
    def check_dependencies(self):
        """فحص المتطلبات والتبعيات"""
        logger.info("فحص المتطلبات...")
        
        # فحص Python packages
        required_packages = [
            ('requests', 'requests'),
            ('feedparser', 'feedparser'), 
            ('beautifulsoup4', 'bs4'),
            ('flask', 'flask'),
            ('flask-cors', 'flask_cors'),
            ('jinja2', 'jinja2'),
            ('schedule', 'schedule')
        ]
        
        missing_packages = []
        for package_name, import_name in required_packages:
            try:
                __import__(import_name)
            except ImportError:
                missing_packages.append(package_name)
        
        if missing_packages:
            logger.error(f"المكتبات المفقودة: {', '.join(missing_packages)}")
            logger.info("تشغيل: pip install -r requirements.txt")
            return False
        
        # فحص الملفات المطلوبة
        required_files = [
            'rss_collector.py',
            'api_collector.py', 
            'content_generator.py',
            'api_server.py',
            'scheduler.py'
        ]
        
        for file in required_files:
            if not os.path.exists(file):
                logger.error(f"الملف المطلوب غير موجود: {file}")
                return False
        
        # إنشاء المجلدات المطلوبة
        directories = [
            'generated_content/articles',
            'generated_content/matches', 
            'generated_content/summaries',
            'generated_content/standings',
            'logs',
            'backups'
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
        
        logger.info("تم فحص المتطلبات بنجاح")
        return True
    
    def run_collector_only(self):
        """تشغيل جمع البيانات فقط"""
        logger.info("تشغيل وضع جمع البيانات فقط...")
        
        try:
            from rss_collector import RSSCollector
            from api_collector import APIFootballCollector
            
            # جمع البيانات من RSS
            rss_collector = RSSCollector()
            rss_results = rss_collector.collect_all_sources()
            
            # جمع البيانات من API
            api_collector = APIFootballCollector()
            api_results = api_collector.collect_daily_data()
            
            # طباعة النتائج
            print("\n=== نتائج جمع البيانات ===")
            print(f"مقالات RSS جديدة: {sum(rss_results.values())}")
            print(f"مباريات API: {api_results.get('fixtures', 0)}")
            print(f"جداول ترتيب: {api_results.get('standings', 0)}")
            
            return True
            
        except Exception as e:
            logger.error(f"خطأ في جمع البيانات: {e}")
            return False
    
    def run_generator_only(self):
        """تشغيل توليد المحتوى فقط"""
        logger.info("تشغيل وضع توليد المحتوى فقط...")
        
        try:
            from content_generator import ContentGenerator
            
            generator = ContentGenerator()
            results = generator.generate_all_content()
            
            # طباعة النتائج
            print("\n=== نتائج توليد المحتوى ===")
            print(f"المقالات المولدة: {results.get('articles', 0)}")
            print(f"تقارير المباريات: {results.get('matches', 0)}")
            print(f"الملخصات اليومية: {results.get('daily_summary', 0)}")
            
            return True
            
        except Exception as e:
            logger.error(f"خطأ في توليد المحتوى: {e}")
            return False
    
    def run_api_server(self):
        """تشغيل خادم API"""
        logger.info("تشغيل خادم API...")
        
        try:
            process = subprocess.Popen([
                sys.executable, 'api_server.py'
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            self.processes['api_server'] = process
            logger.info(f"تم تشغيل خادم API (PID: {process.pid})")
            
            return process
            
        except Exception as e:
            logger.error(f"خطأ في تشغيل خادم API: {e}")
            return None
    
    def run_scheduler(self):
        """تشغيل نظام الجدولة"""
        logger.info("تشغيل نظام الجدولة...")
        
        try:
            process = subprocess.Popen([
                sys.executable, 'scheduler.py'
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            self.processes['scheduler'] = process
            logger.info(f"تم تشغيل نظام الجدولة (PID: {process.pid})")
            
            return process
            
        except Exception as e:
            logger.error(f"خطأ في تشغيل نظام الجدولة: {e}")
            return None
    
    def run_dashboard(self):
        """تشغيل لوحة التحكم"""
        logger.info("تشغيل لوحة التحكم...")
        
        try:
            dashboard_dir = 'sports-admin-dashboard'
            if os.path.exists(dashboard_dir):
                process = subprocess.Popen([
                    'npm', 'run', 'dev', '--', '--host'
                ], cwd=dashboard_dir, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                self.processes['dashboard'] = process
                logger.info(f"تم تشغيل لوحة التحكم (PID: {process.pid})")
                logger.info("لوحة التحكم متاحة على: http://localhost:5173")
                
                return process
            else:
                logger.warning("مجلد لوحة التحكم غير موجود")
                return None
                
        except Exception as e:
            logger.error(f"خطأ في تشغيل لوحة التحكم: {e}")
            return None
    
    def run_full_system(self):
        """تشغيل النظام الكامل"""
        logger.info("تشغيل النظام الكامل...")
        
        # تشغيل خادم API
        api_process = self.run_api_server()
        if not api_process:
            logger.error("فشل في تشغيل خادم API")
            return False
        
        # انتظار قصير لبدء الخادم
        time.sleep(2)
        
        # تشغيل نظام الجدولة
        scheduler_process = self.run_scheduler()
        if not scheduler_process:
            logger.error("فشل في تشغيل نظام الجدولة")
            return False
        
        # تشغيل لوحة التحكم
        dashboard_process = self.run_dashboard()
        
        logger.info("تم تشغيل النظام الكامل بنجاح")
        logger.info("المكونات النشطة:")
        for name, process in self.processes.items():
            if process and process.poll() is None:
                logger.info(f"  - {name}: PID {process.pid}")
        
        # انتظار العمليات
        try:
            while self.running:
                # فحص حالة العمليات
                for name, process in list(self.processes.items()):
                    if process and process.poll() is not None:
                        logger.warning(f"العملية {name} توقفت (exit code: {process.returncode})")
                        del self.processes[name]
                
                time.sleep(10)
                
        except KeyboardInterrupt:
            logger.info("تم إيقاف النظام بواسطة المستخدم")
        
        return True
    
    def stop_all_processes(self):
        """إيقاف جميع العمليات"""
        logger.info("إيقاف جميع العمليات...")
        
        for name, process in self.processes.items():
            if process and process.poll() is None:
                logger.info(f"إيقاف {name}...")
                try:
                    process.terminate()
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    logger.warning(f"فرض إيقاف {name}...")
                    process.kill()
                except Exception as e:
                    logger.error(f"خطأ في إيقاف {name}: {e}")
        
        self.processes.clear()
        logger.info("تم إيقاف جميع العمليات")
    
    def show_status(self):
        """عرض حالة النظام"""
        print("\n=== حالة نظام أتمتة المحتوى الرياضي ===")
        
        # فحص قاعدة البيانات
        if os.path.exists('sports_content.db'):
            import sqlite3
            try:
                conn = sqlite3.connect('sports_content.db')
                cursor = conn.cursor()
                
                cursor.execute("SELECT COUNT(*) FROM articles")
                articles_count = cursor.fetchone()[0]
                
                cursor.execute("SELECT COUNT(*) FROM matches")
                matches_count = cursor.fetchone()[0]
                
                print(f"قاعدة البيانات: ✓")
                print(f"  - المقالات: {articles_count}")
                print(f"  - المباريات: {matches_count}")
                
                conn.close()
            except Exception as e:
                print(f"قاعدة البيانات: ✗ ({e})")
        else:
            print("قاعدة البيانات: ✗ (غير موجودة)")
        
        # فحص المحتوى المولد
        content_dirs = {
            'المقالات': 'generated_content/articles',
            'المباريات': 'generated_content/matches',
            'الملخصات': 'generated_content/summaries'
        }
        
        print("\nالمحتوى المولد:")
        for name, path in content_dirs.items():
            if os.path.exists(path):
                count = len([f for f in os.listdir(path) if f.endswith('.md')])
                print(f"  - {name}: {count} ملف")
            else:
                print(f"  - {name}: 0 ملف")
        
        # فحص العمليات النشطة
        print(f"\nالعمليات النشطة: {len(self.processes)}")
        for name, process in self.processes.items():
            if process and process.poll() is None:
                print(f"  - {name}: نشط (PID {process.pid})")
            else:
                print(f"  - {name}: متوقف")
        
        print()

def main():
    """الدالة الرئيسية"""
    parser = argparse.ArgumentParser(
        description='نظام أتمتة المحتوى الرياضي',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
أمثلة الاستخدام:
  python main.py --full              تشغيل النظام الكامل
  python main.py --collect           جمع البيانات فقط
  python main.py --generate          توليد المحتوى فقط
  python main.py --api-server        تشغيل خادم API فقط
  python main.py --scheduler         تشغيل الجدولة فقط
  python main.py --dashboard         تشغيل لوحة التحكم فقط
  python main.py --status            عرض حالة النظام
        """
    )
    
    parser.add_argument('--full', action='store_true',
                       help='تشغيل النظام الكامل (افتراضي)')
    parser.add_argument('--collect', action='store_true',
                       help='جمع البيانات فقط')
    parser.add_argument('--generate', action='store_true',
                       help='توليد المحتوى فقط')
    parser.add_argument('--api-server', action='store_true',
                       help='تشغيل خادم API فقط')
    parser.add_argument('--scheduler', action='store_true',
                       help='تشغيل نظام الجدولة فقط')
    parser.add_argument('--dashboard', action='store_true',
                       help='تشغيل لوحة التحكم فقط')
    parser.add_argument('--status', action='store_true',
                       help='عرض حالة النظام')
    
    args = parser.parse_args()
    
    # إنشاء النظام
    system = SportsAutomationSystem()
    
    # فحص المتطلبات
    if not system.check_dependencies():
        logger.error("فشل في فحص المتطلبات")
        sys.exit(1)
    
    # تنفيذ الأمر المطلوب
    try:
        if args.status:
            system.show_status()
        elif args.collect:
            success = system.run_collector_only()
            sys.exit(0 if success else 1)
        elif args.generate:
            success = system.run_generator_only()
            sys.exit(0 if success else 1)
        elif args.api_server:
            system.run_api_server()
            # انتظار العملية
            while system.processes.get('api_server') and system.processes['api_server'].poll() is None:
                time.sleep(1)
        elif args.scheduler:
            system.run_scheduler()
            # انتظار العملية
            while system.processes.get('scheduler') and system.processes['scheduler'].poll() is None:
                time.sleep(1)
        elif args.dashboard:
            system.run_dashboard()
            # انتظار العملية
            while system.processes.get('dashboard') and system.processes['dashboard'].poll() is None:
                time.sleep(1)
        else:
            # تشغيل النظام الكامل (افتراضي)
            system.run_full_system()
            
    except KeyboardInterrupt:
        logger.info("تم إيقاف النظام بواسطة المستخدم")
    except Exception as e:
        logger.error(f"خطأ في تشغيل النظام: {e}")
        sys.exit(1)
    finally:
        system.stop_all_processes()

if __name__ == "__main__":
    main()
